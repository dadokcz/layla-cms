<?php
namespace GlobalPayments\Api\Entities\Reporting;

class AltPaymentProcessorInfo
{
    /**
     * @var string
     */
    public $code;
    
    /**
     * @var string
     */
    public $message;
    
    /**
     * @var string
     */
    public $type;
}
