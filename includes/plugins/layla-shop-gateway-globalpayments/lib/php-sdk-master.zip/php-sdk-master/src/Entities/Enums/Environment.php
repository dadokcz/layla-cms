<?php

namespace GlobalPayments\Api\Entities\Enums;

use GlobalPayments\Api\Entities\Enum;

class Environment extends Enum
{
    const TEST = "TEST";
    const PRODUCTION = "PRODUCTION";
}
