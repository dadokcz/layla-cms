<?php

namespace GlobalPayments\Api\Entities\Enums;

use GlobalPayments\Api\Entities\Enum;

class MessageVersion extends Enum
{
    const VERSION_210 = "2.1.0";
}
