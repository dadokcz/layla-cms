<?php

namespace GlobalPayments\Api\Entities\Enums;

use GlobalPayments\Api\Entities\Enum;

class DccProcessor extends Enum
{
    const FEXCO = 'Fexco';
    const EUROCONEX = 'Euroconex';
}
