<?php

namespace GlobalPayments\Api\Entities\Enums;

use GlobalPayments\Api\Entities\Enum;

class HppVersion extends Enum
{
    const VERSION_1 = '1';
    const VERSION_2 = '2';
}
