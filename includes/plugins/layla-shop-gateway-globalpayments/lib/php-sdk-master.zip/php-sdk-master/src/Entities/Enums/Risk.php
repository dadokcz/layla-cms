<?php

namespace GlobalPayments\Api\Entities\Enums;

use GlobalPayments\Api\Entities\Enum;

class Risk extends Enum
{
    const HIGH = 'HIGH';
    const LOW = 'LOW';
}
