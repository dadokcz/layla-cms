<?php

namespace GlobalPayments\Api\Terminals\Enums;

use GlobalPayments\Api\Entities\Enum;

class StopBits extends Enum
{
    const ONE = 1;
    const TWO = 2;
}
