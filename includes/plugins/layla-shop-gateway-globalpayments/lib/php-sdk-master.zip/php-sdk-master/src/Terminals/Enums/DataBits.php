<?php

namespace GlobalPayments\Api\Terminals\Enums;

use GlobalPayments\Api\Entities\Enum;

class DataBits extends Enum
{
    const SEVEN = 7;
    const EIGHT = 8;
}
