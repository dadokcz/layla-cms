<?php

namespace GlobalPayments\Api\Terminals\Enums;

use GlobalPayments\Api\Entities\Enum;

class ApplicationCryptogramType extends Enum
{
    const TC = 'TC';
    const ARQC = 'ARQC';
}
