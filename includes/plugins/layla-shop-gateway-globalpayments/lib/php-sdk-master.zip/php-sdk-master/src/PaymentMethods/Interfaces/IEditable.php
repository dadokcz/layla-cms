<?php

namespace GlobalPayments\Api\PaymentMethods\Interfaces;

interface IEditable
{
    public function edit($amount = null);
}
