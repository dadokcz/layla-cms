<?php

namespace GlobalPayments\Api\PaymentMethods\Interfaces;

interface IVerifyable
{
    public function verify();
}
