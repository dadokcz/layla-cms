<?php

namespace GlobalPayments\Api\PaymentMethods\Interfaces;

use GlobalPayments\Api\Entities\ThreeDSecure;

interface ISecure3d
{
    
}
