<?php

namespace GlobalPayments\Api\PaymentMethods\Interfaces;

interface IPaymentMethod
{
}
