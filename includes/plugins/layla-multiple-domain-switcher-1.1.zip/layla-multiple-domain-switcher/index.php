<?php

/* Plugin name: Multiple Domain Switcher */
/* Plugin version: 1.1 */
/* Plugin description: {{Fast switching between domains with LaylaCMS}} */
/* Author: DADOK - Global Internet Solutions (dadok.cz) */
/* Plugin category: utilities */
/* Plugin price: 19 */
